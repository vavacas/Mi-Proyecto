package com.example.myapplication3

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import java.util.Calendar

const val limiteTarjetas = 4

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Inicializo mi objeto global
        MiListaGlobal.inicializar(this)

        val btnMisTarjetas = findViewById<Button>(R.id.btnMisTarjetas)
        // Código que se ejecuta al hacer click en botón MIS TARJETAS
        btnMisTarjetas.setOnClickListener {
            if (MiListaGlobal.miListaNumTtas.isEmpty())
                Toast.makeText(this,"No hay tarjetas para mostrar",Toast.LENGTH_SHORT).show()
            else {
                // Para abrir otra actividad creo un Intent
                val intent = Intent(this, TarjetasActivity::class.java)
                // Inicio TarjetasActivity
                startActivity(intent)
            }
        }

        val btnNueva = findViewById<Button>(R.id.btnNueva)
        // Lanzar popup con el click en botón NUEVA
        btnNueva.setOnClickListener {
            if (MiListaGlobal.miListaNumTtas.size == limiteTarjetas )
            //Mostrar mensaje de error
                Toast.makeText(this, "Monedero lleno. Límite: $limiteTarjetas tarjetas.", Toast.LENGTH_SHORT).show()
            else
            // Pido los datos de la tarjeta
                lanzarPopupsNueva()
        }

        val btnSalir = findViewById<Button>(R.id.btnSalir)
        // Código que se ejecuta al hacer click en botón SALIR
        btnSalir.setOnClickListener {
            // Guardo las listas de alias, ttas y fcdad para no perderlas
            MiListaGlobal.guardarListaG(MiListaGlobal.miListaAlias,MiListaGlobal.ALIAS)
            MiListaGlobal.guardarListaG(MiListaGlobal.miListaNumTtas,MiListaGlobal.TTAS)
            MiListaGlobal.guardarListaG(MiListaGlobal.miListaCdades,MiListaGlobal.CDADS)
            // Cierra la actividad actual y tb cierra la app, si no hay más Activity en la pila
            finish()
        }
    }

    private fun lanzarPopupsNueva() {

        //Creo el popup de TARJETA
        val miPopupTta = AlertDialog.Builder(this)
        miPopupTta.setTitle("Número de tarjeta")
        val tta = EditText(this)
        tta.hint = "0000111122223333"
        tta.inputType = InputType.TYPE_CLASS_NUMBER
        tta.filters = arrayOf(InputFilter.LengthFilter(16))
        miPopupTta.setView(tta)
        miPopupTta.setCancelable(false)
        miPopupTta.create().setCanceledOnTouchOutside(false)
        // Ajustar CANCELAR y SIGUIENTE al popup de TARJETA
        miPopupTta.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
            //Mostrar mensaje de error
            Toast.makeText(this, "Cancelado por el usuario", Toast.LENGTH_SHORT).show()
        }
        miPopupTta.setPositiveButton("Siguiente") { globoSigDialog, _ ->
            // Recupero numTta del popup
            val numTarjeta = tta.text.toString()
            if (esFormatoValidoTta(numTarjeta)) {
                //Creo el popup de CADUCIDAD
                val miPopupCdad = AlertDialog.Builder(this)
                miPopupCdad.setTitle("Fecha de caducidad")
                val cdad = EditText(this)
                cdad.hint = "00/11"
                cdad.filters = arrayOf(InputFilter.LengthFilter(5))
                miPopupCdad.setView(cdad)
                miPopupCdad.setCancelable(false)
                miPopupCdad.create().setCanceledOnTouchOutside(false)
                // Ajustar CANCELAR y ACEPTAR al popup de CADUCIDAD
                miPopupCdad.setNegativeButton("Cancelar") { globoDialog, _ ->
                    globoDialog.cancel()
                    //Mostrar mensaje de error
                    Toast.makeText(this, "Cancelado por el usuario", Toast.LENGTH_SHORT).show()
                }
                miPopupCdad.setPositiveButton("Siguiente") { globoDialog, _ ->
                    // Recupero la fcdad del popup
                    val fCdad = cdad.text.toString()
                    if (esFormatoValidoCdad(fCdad) && fCadLogica(fCdad)) { // En esta rama el fto de fecha es válido y NO está caducada
                        if (!existeTta(numTarjeta)) { // Si no existe la tarjeta, pido alias y la guardo
                            //Creo el popup de ALIAS
                            val miPopupAlias = AlertDialog.Builder(this)
                            miPopupAlias.setTitle("Alias de tarjeta")
                            val alias = EditText(this)
                            alias.hint = "Ej: nombre del banco"
                            alias.filters = arrayOf(InputFilter.LengthFilter(15))
                            miPopupAlias.setView(alias)
                            miPopupAlias.setCancelable(false)
                            miPopupAlias.create().setCanceledOnTouchOutside(false)
                            miPopupAlias.setNegativeButton("Cancelar") { globoCancelDialog, _ ->
                                globoCancelDialog.cancel()
                                //Mostrar mensaje de error
                                Toast.makeText(this, "Cancelado por el usuario", Toast.LENGTH_SHORT).show()
                            }
                            miPopupAlias.setPositiveButton("Aceptar") { _ , _ ->
                                val aliasCadena = alias.text.toString()
                                // Guardo el trío de valores
                                MiListaGlobal.guardarTta(numTarjeta)
                                MiListaGlobal.guardarListaG(MiListaGlobal.miListaNumTtas,MiListaGlobal.TTAS)
                                MiListaGlobal.guardarCdad(fCdad)
                                MiListaGlobal.guardarListaG(MiListaGlobal.miListaCdades,MiListaGlobal.CDADS)
                                MiListaGlobal.guardarAlias(aliasCadena)
                                MiListaGlobal.guardarListaG(MiListaGlobal.miListaAlias,MiListaGlobal.ALIAS)
                            }
                            miPopupAlias.show()
                        }
                        else
                            if (!existeTtaDupl(numTarjeta)) {
                                val fCadAlmacenada = MiListaGlobal.miListaCdades[MiListaGlobal.miListaNumTtas.indexOf(numTarjeta)]
                                if (fCdad == fCadAlmacenada)
                                    Toast.makeText(this,"Tarjeta no añadida. ¡¡Esta tarjeta ya existe!!",Toast.LENGTH_LONG).show()
                                // Añado tarjeta con misma numeración, diferente FCdad
                                else {
                                    //Creo el popup de ALIAS
                                    val miPopupAlias = AlertDialog.Builder(this)
                                    miPopupAlias.setTitle("Alias de tarjeta")
                                    val alias = EditText(this)
                                    alias.hint = "Ej: nombre del banco"
                                    alias.filters = arrayOf(InputFilter.LengthFilter(15))
                                    miPopupAlias.setView(alias)
                                    miPopupAlias.setCancelable(false)
                                    miPopupAlias.create().setCanceledOnTouchOutside(false)
                                    miPopupAlias.setNegativeButton("Cancelar") { globoCancelDialog, _ ->
                                        globoCancelDialog.cancel()
                                        //Mostrar mensaje de error
                                        Toast.makeText(this, "Cancelado por el usuario", Toast.LENGTH_SHORT).show()
                                    }
                                    // Guardo el trío de valores
                                    miPopupAlias.setPositiveButton("Aceptar") { _ , _ ->
                                        val aliasCadena = alias.text.toString()
                                        MiListaGlobal.guardarTta(numTarjeta)
                                        MiListaGlobal.guardarListaG(MiListaGlobal.miListaNumTtas,MiListaGlobal.TTAS)
                                        MiListaGlobal.guardarCdad(fCdad)
                                        MiListaGlobal.guardarListaG(MiListaGlobal.miListaCdades,MiListaGlobal.CDADS)
                                        MiListaGlobal.guardarAlias(aliasCadena)
                                        MiListaGlobal.guardarListaG(MiListaGlobal.miListaAlias,MiListaGlobal.ALIAS)
                                        Toast.makeText(this,"Tarjeta añadida. ¡Hay dos tarjetas con la misma numeración!",Toast.LENGTH_LONG).show()
                                    }
                                    miPopupAlias.show()
                                }
                            }
                            // No puede haber más de dos tarjetas con la misma numeración
                            else
                                Toast.makeText(this,"Tarjeta no añadida. Ya hay dos tarjetas con la misma numeración!",Toast.LENGTH_LONG).show()


                    }
                    else
                    // Formato de caducidad no válido
                        if (!esFormatoValidoCdad(fCdad)) {
                            // Cerramos popup de CADUCIDAD
                            globoDialog.dismiss()
                            //Muestro mensaje de error
                            Toast.makeText(this,"Formato de caducidad no válido",Toast.LENGTH_SHORT).show()
                        }
                        // Si hay fto válido de caducidad, pero la fecha es antigua
                        else {
                            // Cerramos popup de CADUCIDAD
                            globoDialog.dismiss()
                            // Muestro mensaje de error
                            Toast.makeText(this,"Tarjeta no añadida: está caducada!",Toast.LENGTH_SHORT).show()
                        }
                }
                miPopupCdad.show()
            }
            // Formato de numeración de tarjeta no válido
            else {
                // Cerramos popup de TARJETA
                globoSigDialog.dismiss()
                // Mostrar mensaje de error
                Toast.makeText(this, "Formato de tarjeta no válido", Toast.LENGTH_SHORT).show()
            }
        }
        miPopupTta.show()
    }

    private fun fCadLogica (fCad: String): Boolean {
        val mSist = obtenerMesSist()
        val aSist = obtenerAnioSist()
        val mRecibido = fCad.take(2).toInt()
        val aRecibido = fCad.takeLast(2).toInt()
        if (aRecibido < aSist) return false
        return !(aRecibido==aSist && mRecibido<mSist)
    }

    private fun obtenerMesSist(): Int {
        val fActual = Calendar.getInstance()
        return fActual.get(Calendar.MONTH) + 1
    }

    private fun obtenerAnioSist(): Int {
        val fActual = Calendar.getInstance()
        return fActual.get(Calendar.YEAR) % 100
    }

    private fun existeTtaDupl (numTarjeta: String): Boolean {
        return MiListaGlobal.miListaNumTtas.count { it == numTarjeta } > 1
    }

    private fun existeTta (numTarjeta: String): Boolean {
        return MiListaGlobal.miListaNumTtas.contains(numTarjeta)
    }

    private fun esFormatoValidoTta (numTta: String): Boolean {
        // Lleva comilla doble 3 veces para poder escribir la expresión regular en crudo
        val expresionReg = Regex("""^\d{16}$""")
        return expresionReg.matches(numTta)
    }

    private fun esFormatoValidoCdad (paramCdad: String): Boolean {
        val expresionReg = Regex("^(0[1-9]|1[0-2])/([0-9]{2})$")
        return expresionReg.matches(paramCdad)
    }
}
