package com.example.myapplication3

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

object MiListaGlobal {

    // CONSTANTES
    const val TTAS = "Tarjetas"
    const val CDADS = "Caducidades"
    const val ALIAS = "Alias"

    // Creo 3 listas modificables de Strings (para poder añadir y eliminar elementos)
    lateinit var miListaNumTtas: MutableList<String>
    lateinit var miListaCdades: MutableList<String>
    lateinit var miListaAlias: MutableList<String>

    // Creo las sharedP para dar PERSISTENCIA a los datos de la APP
    private lateinit var sharedPrefListaTtas: SharedPreferences
    private lateinit var sharedPrefListaCdads: SharedPreferences
    private lateinit var sharedPrefListaAlias: SharedPreferences

    // Creo objeto Gson para serializ/deserializ mis listas al guardar/recuperar elementos
    // y así poder mantener el orden de los elementos en en sharedP (ya que éste de forma nativa
    // no lo garantiza)
    private val gson = Gson()

    fun inicializar (context: Context){
        sharedPrefListaTtas = context.getSharedPreferences("MisPreferences_Ttas", Context.MODE_PRIVATE)
        sharedPrefListaCdads = context.getSharedPreferences("MisPreferences_Cdads", Context.MODE_PRIVATE)
        sharedPrefListaAlias = context.getSharedPreferences("MisPreferences_Alias", Context.MODE_PRIVATE )
        miListaNumTtas = obtenerListaG(TTAS)
        miListaCdades = obtenerListaG(CDADS)
        miListaAlias = obtenerListaG(ALIAS)
    }

    fun guardarTta (numTta: String){
        miListaNumTtas.add(numTta)
    }

    fun eliminarTta (indice: Int){
        miListaNumTtas.removeAt(indice)
    }

    fun guardarCdad (cdad: String){
        miListaCdades.add(cdad)
    }

    fun eliminarCdad (indice: Int){
        miListaCdades.removeAt(indice)
    }

    fun guardarAlias (alias: String){
        miListaAlias.add(alias)
    }

    fun eliminarAlias (indice: Int){
        miListaAlias.removeAt(indice)
    }

    private fun obtenerListaG (clave: String): MutableList<String> {
        // Deserializo para conservar el orden
        var listaDeserial = sharedPrefListaAlias.getString(clave, null)
        if (clave == TTAS)
            listaDeserial = sharedPrefListaTtas.getString (clave, null)
        else
            if (clave == CDADS)
                listaDeserial = sharedPrefListaCdads.getString (clave, null)

        if (listaDeserial != null)
            return gson.fromJson(listaDeserial, MutableList::class.java) as MutableList<String>
        else
            return mutableListOf()
    }

    fun guardarListaG (lista: MutableList<String>, clave: String){
        //Serializo la lista para conservar el orden de los elem en el sharedP después
        val listaSerial = gson.toJson(lista)
        when (clave) {
            TTAS -> sharedPrefListaTtas.edit().putString(clave, listaSerial).apply()
            CDADS -> sharedPrefListaCdads.edit().putString(clave, listaSerial).apply()
            ALIAS -> sharedPrefListaAlias.edit().putString(clave, listaSerial).apply()
        }
    }
}