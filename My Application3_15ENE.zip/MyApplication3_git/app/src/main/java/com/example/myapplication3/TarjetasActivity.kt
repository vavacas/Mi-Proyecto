package com.example.myapplication3

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

const val campoVacioCdad = " Fecha de caducidad"
const val campoVacioTta = "Número de tarjeta"
const val campoVacioAlias = "Alias de tarjeta"

class TarjetasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tarjetas)

        /*Declaro variables de los TextView para los botones COPIAR*/
        val tvNum1 = findViewById<TextView>(R.id.tvNumeracion1)
        val tvCad1 = findViewById<TextView>(R.id.tvCaducidad1)
        val tvNum2 = findViewById<TextView>(R.id.tvNumeracion2)
        val tvCad2 = findViewById<TextView>(R.id.tvCaducidad2)
        val tvNum3 = findViewById<TextView>(R.id.tvNumeracion3)
        val tvCad3 = findViewById<TextView>(R.id.tvCaducidad3)
        val tvNum4 = findViewById<TextView>(R.id.tvNumeracion4)
        val tvCad4 = findViewById<TextView>(R.id.tvCaducidad4)

        pintarTextView()

        val btnCpT1 = findViewById<Button>(R.id.btnCpTta1)
        /* Código que se ejecuta al hacer click en botón COPIAR TARJETA 1 */
        btnCpT1.setOnClickListener {
            /* Obtengo el contenido del TextView de la tta */
            val tta = tvNum1.text.toString()
            // Muestro mensaje de error
            if(tta == campoVacioTta)
                Toast.makeText(this, "No hay tarjeta registrada", Toast.LENGTH_SHORT).show()
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(tta)
                // Muestro mensaje
                Toast.makeText(this, "Tarjeta 1 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpC1 = findViewById<Button>(R.id.btnCpCdad1)
        /* Código que se ejecuta al hacer click en botón COPIAR CADUCIDAD 1 */
        btnCpC1.setOnClickListener {
            // Obtengo el contenido del TextView de la fcdad
            val cad = tvCad1.text.toString()
            if (cad == campoVacioCdad)
            // Muestro mensaje de error
                Toast.makeText(this, "No hay caducidad registrada", Toast.LENGTH_SHORT).show()
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(cad)
                // Muestro mensaje
                Toast.makeText(this, "Fecha de caducidad 1 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpT2 = findViewById<Button>(R.id.btnCpTta2)
        // Código que se ejecuta al hacer click en botón COPIAR TARJETA 2
        btnCpT2.setOnClickListener {
            // Obtengo el contenido del TextView de la tta
            val tta = tvNum2.text.toString()
            if(tta == campoVacioTta)
            // Muestro mensaje de error
                Toast.makeText(this, "No hay tarjeta registrada", Toast.LENGTH_SHORT).show()
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(tta)
                // Muestro mensaje
                Toast.makeText(this, "Tarjeta 2 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpC2 = findViewById<Button>(R.id.btnCpCdad2)
        // Código que se ejecuta al hacer click en botón COPIAR CADUCIDAD 2
        btnCpC2.setOnClickListener {
            // Obtengo el contenido del TextView de la fcdad
            val cad = tvCad2.text.toString()
            if (cad == campoVacioCdad) {
                // Muestro mensaje de error
                Toast.makeText(this, "No hay caducidad registrada", Toast.LENGTH_SHORT).show()
            }
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(cad)
                // Muestro mensaje
                Toast.makeText(this, "Fecha de caducidad 2 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpT3 = findViewById<Button>(R.id.btnCpTta3)
        // Código que se ejecuta al hacer click en botón COPIAR TARJETA 3
        btnCpT3.setOnClickListener {
            // Obtengo el contenido del TextView de la tta
            val tta = tvNum3.text.toString()
            if(tta == campoVacioTta){
                // Muestro mensaje de error
                Toast.makeText(this, "No hay tarjeta registrada", Toast.LENGTH_SHORT).show()
            }
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(tta)
                // Muestro mensaje
                Toast.makeText(this, "Tarjeta 3 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpC3 = findViewById<Button>(R.id.btnCpCdad3)
        // Código que se ejecuta al hacer click en botón COPIAR CADUCIDAD 3
        btnCpC3.setOnClickListener {
            // Obtengo el contenido del TextView de la fcdad
            val cad = tvCad3.text.toString()
            if (cad == campoVacioCdad) {
                // Muestro mensaje de error
                Toast.makeText(this, "No hay caducidad registrada", Toast.LENGTH_SHORT).show()
            }
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(cad)
                // Muestro mensaje
                Toast.makeText(this, "Fecha de caducidad 3 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpT4 = findViewById<Button>(R.id.btnCpTta4)
        // Código que se ejecuta al hacer click en botón COPIAR TARJETA 4
        btnCpT4.setOnClickListener {
            // Obtengo el contenido del TextView de la tta
            val tta = tvNum4.text.toString()
            if(tta == campoVacioTta){
                // Muestro mensaje de error
                Toast.makeText(this, "No hay tarjeta registrada", Toast.LENGTH_SHORT).show()
            }
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(tta)
                // Muestro mensaje
                Toast.makeText(this, "Tarjeta 4 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }

        val btnCpC4 = findViewById<Button>(R.id.btnCpCdad4)
        // Código que se ejecuta al hacer click en botón COPIAR CADUCIDAD 4
        btnCpC4.setOnClickListener {
            // Obtengo el contenido del TextView de la Fcdad
            val cad = tvCad4.text.toString()
            if (cad == campoVacioCdad) {
                // Muestro mensaje de error
                Toast.makeText(this, "No hay caducidad registrada", Toast.LENGTH_SHORT).show()
            }
            else {
                // Copio al portapapeles
                copiarAlPortapapeles(cad)
                // Muestro mensaje
                Toast.makeText(this, "Fecha de caducidad 4 copiada al portapapeles", Toast.LENGTH_SHORT).show()
            }
        }


        val btnEliminar = findViewById<Button>(R.id.btnEliminar)
        // Código que se ejecuta al hacer click en botón ELIMINAR
        btnEliminar.setOnClickListener {
            // Solicita qué tarjeta se quiere eliminar
            lanzarPopupSeleccionTta()
        }


        val btnVolver = findViewById<Button>(R.id.btnVolver)
        // Código que se ejecuta al hacer click en botón VOLVER
        btnVolver.setOnClickListener {
            //Elimina la Activity de la pila; vuelve a la Activity llamante de ésta
            finish()
        }
    }

    private fun copiarAlPortapapeles (cadena: String){
        // Creo una variable para usar el portapapeles
        val portapapeles = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        // Creo una var de tipo ClipData con el texto a copiar
        val datos = ClipData.newPlainText("", cadena)
        // Pongo la cadena copiada en el portapapeles
        portapapeles.setPrimaryClip(datos)
    }

    private fun lanzarPopupSeleccionTta (){

        //Creo el popup de ELIMINAR
        val miPopupTta = AlertDialog.Builder(this)
        miPopupTta.setTitle("Seleciona número de tarjeta:")
        val tta = EditText(this)
        tta.hint = "Ej: 1"
        tta.inputType = InputType.TYPE_CLASS_NUMBER
        tta.filters = arrayOf(InputFilter.LengthFilter(1))
        miPopupTta.setView(tta)
        miPopupTta.setCancelable(false)
        miPopupTta.create().setCanceledOnTouchOutside(false)
        miPopupTta.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
            //Mostrar mensaje al usuario de CANCELAR
            Toast.makeText(this, "Cancelado por el usuario", Toast.LENGTH_SHORT).show()
        }
        miPopupTta.setPositiveButton("Aceptar") { _, _ ->
            procesarValorAEliminar(tta.text.toString())
        }
        miPopupTta.show()
    }

    private fun procesarValorAEliminar (valor: String) {

        val size = MiListaGlobal.miListaNumTtas.size

        when (val valorN = valor.toIntOrNull()) {
            null ->
                //Mostrar mensaje de error
                Toast.makeText(this,"Introduzca un valor de 1 a $limiteTarjetas.",Toast.LENGTH_SHORT).show()
            in 1..4 -> {
                // Si es una entrada válida de 1 a 4
                // El smart cast deduce si valor N es null o integer
                if (size >= valorN) {
                    // Borro Tarjeta que marque el índice y guardo las sharedP
                    val indice = valorN - 1
                    MiListaGlobal.eliminarAlias(indice)
                    MiListaGlobal.guardarListaG(MiListaGlobal.miListaAlias,MiListaGlobal.ALIAS)
                    MiListaGlobal.eliminarTta(indice)
                    MiListaGlobal.guardarListaG(MiListaGlobal.miListaNumTtas,MiListaGlobal.TTAS)
                    MiListaGlobal.eliminarCdad(indice)
                    MiListaGlobal.guardarListaG(MiListaGlobal.miListaCdades,MiListaGlobal.CDADS)
                    pintarTextView()
                }
                else
                // Muestro mensaje de error
                    Toast.makeText(this,"No existe la Tarjeta $valor",Toast.LENGTH_SHORT).show()
            }
            else ->
                // El valor es un número, pero NO existe esa tarjeta
                Toast.makeText(this,"No existe la Tarjeta $valor. El límite de tarjetas es: $limiteTarjetas.",Toast.LENGTH_SHORT).show()
        }
    }
    private fun pintarTextView () {
        // Declaro mis variables para pintar los TextView
        val tvNum1 = findViewById<TextView>(R.id.tvNumeracion1)
        val tvCad1 = findViewById<TextView>(R.id.tvCaducidad1)
        val tvAlias1 = findViewById<TextView>(R.id.tvTarjeta1)
        val tvNum2 = findViewById<TextView>(R.id.tvNumeracion2)
        val tvCad2 = findViewById<TextView>(R.id.tvCaducidad2)
        val tvAlias2 = findViewById<TextView>(R.id.tvTarjeta2)
        val tvNum3 = findViewById<TextView>(R.id.tvNumeracion3)
        val tvCad3 = findViewById<TextView>(R.id.tvCaducidad3)
        val tvAlias3 = findViewById<TextView>(R.id.tvTarjeta3)
        val tvNum4 = findViewById<TextView>(R.id.tvNumeracion4)
        val tvCad4 = findViewById<TextView>(R.id.tvCaducidad4)
        val tvAlias4 = findViewById<TextView>(R.id.tvTarjeta4)
        val listaTvCdads = mutableListOf<TextView>(tvCad1,tvCad2,tvCad3,tvCad4)
        val listaTvNum = mutableListOf<TextView>(tvNum1,tvNum2,tvNum3,tvNum4)
        val listaTvAlias = mutableListOf<TextView>(tvAlias1,tvAlias2,tvAlias3,tvAlias4)

        val size = MiListaGlobal.miListaNumTtas.size
        if (size == 0)
        //Elimina la Activity de la pila; vuelve a la Activity llamante de ésta (ed, MenuActivity)
            finish()
        else {
            // Actualizo los diferentes TextView
            for (i in MiListaGlobal.miListaNumTtas.indices) {
                listaTvNum[i].text = MiListaGlobal.miListaNumTtas[i]
                listaTvCdads[i].text = MiListaGlobal.miListaCdades[i]
                val j = i+1
                // $j y ${MiListaGlobal.miListaAlias[i]} nunca van a ser NULL
                listaTvAlias[i].text = "Tarjeta $j - ${MiListaGlobal.miListaAlias[i]}"
                if (size < limiteTarjetas){
                    listaTvNum[j].text = campoVacioTta
                    listaTvCdads[j].text = campoVacioCdad
                    listaTvAlias[j].text = campoVacioAlias
                }
            }
        }
    }
}